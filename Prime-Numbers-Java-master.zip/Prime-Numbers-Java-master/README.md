# Prime-Numbers-Java
Finding Prime numbers using Java
<br>
efficient code with two tricks to speed up things<br>
<ol><li>
Even numbers are excluded, as 2 is the only prime which is even<li>
If factors are not there till the approx root of the number, it's a prime</ol><br>
<h2> Source code is available in Python as well</h2>
check my repositery https://github.com/Gopalkataria/Prime-Numbers
